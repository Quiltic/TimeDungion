﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Cursor : MonoBehaviour
{
    private Clicker main;

    public Floor leftGrid;
    public Floor rightGrid;

    public bool rowMode = false;
    public bool colMode = false;


    public GameObject prefab;
    public GameObject[] colGrid;
    public GameObject[] rowGrid;
    

    // Start is called before the first frame update
    void Start()
    {
        main = GameObject.Find("Main Camera").GetComponent<Clicker>();
        leftGrid = GameObject.Find("LeftSide").GetComponent<Floor>();
        rightGrid = GameObject.Find("RightSide").GetComponent<Floor>();
        //main.Click += Clicked;


        /*
        for (int y = 0; y < (2*leftGrid.scale-1); y++) {
                GameObject bab = Instantiate(prefab, (gameObject.transform.position + new Vector3(0, (-y*0.7f)+1, -y)), Quaternion.identity);
                bab.transform.parent = gameObject.transform;
                //bab.transform.localScale += new Vector3(-0.4f,-0.4f,-0.4f);
                bab.GetComponent<Icon>().ToggleVisable(false);
                colGrid[y] = bab;
        }


        for (int x = 0; x < leftGrid.scale; x++) {
                GameObject bab = Instantiate(prefab, (gameObject.transform.position + new Vector3(x , 0 , -2)), Quaternion.identity);
                bab.transform.parent = gameObject.transform;
                //bab.transform.localScale += new Vector3(-0.4f,-0.4f,-0.4f);
                bab.GetComponent<Icon>().ToggleVisable(false);
                rowGrid[x] = bab;
        }
        */


        
        gameObject.transform.localScale += new Vector3(leftGrid.enlarge,leftGrid.enlarge,leftGrid.enlarge);



    }

    // Update is called once per frame
    void Update()
    {
        if (main.hover)
            gameObject.transform.position = main.hover.transform.position;
    }
}
