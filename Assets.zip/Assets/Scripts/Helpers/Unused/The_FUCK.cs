﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class The_FUCK : MonoBehaviour
{
    // Start is called before the first frame update


    //UnityEvent m_MyEvent;


    public string lastClicked = "None";
    public string clicked = "None";
    public float clickPosX = 0;
    public float clickPosY = 0;
    public string State = "None";
    public int Pain = 10;
    public int Heal = 10;
    public float Mult = 1f;

    void Start()
    {
        Debug.Log("FACK");
        //if (m_MyEvent == null)
        //    m_MyEvent = new UnityEvent();

        //m_MyEvent.AddListener(Ping);
    }
    // Update is called once per frame
    void Update () {
        if (clicked != "None"){
            clicked = "None";
        }

        if (Input.GetMouseButtonDown(0)) {
            
            Vector3 mousePos = Camera.main.ScreenToWorldPoint(Input.mousePosition);
            Vector2 mousePos2D = new Vector2(mousePos.x, mousePos.y);
            
            RaycastHit2D hit = Physics2D.Raycast(mousePos2D, Vector2.zero);
            if (hit.collider != null) {
                    lastClicked = hit.collider.gameObject.name;
                clickPosX = mousePos.x;
                clickPosY = mousePos.y;
                //gameObject.SendMessage(, 5.0);
            }

                //Debug.Log(lastClicked);
                //hit.collider.attachedRigidbody.AddForce(Vector2.up);
            
        }
        if (Input.GetMouseButtonUp(0)) {
            //Vector3 mousePos = Camera.main.ScreenToWorldPoint(Input.mousePosition);
            //Vector2 mousePos2D = new Vector2(mousePos.x, mousePos.y);
            
            //RaycastHit2D hit = Physics2D.Raycast(mousePos2D, Vector2.zero);
            //if (hit.collider != null) {
                clicked = lastClicked;
                lastClicked = "None";//hit.collider.gameObject.name;
                clickPosX = 0;//mousePos.x;
                clickPosY = 0;//mousePos.y;
                
                //Debug.Log(lastClicked);
                //hit.collider.attachedRigidbody.AddForce(Vector2.up);
            //}
        }
    }


   

    //For ease of access all types of damage moves are listed here. for now

    public int CLICKED(string name){
        if (name == "Player")
            return((int)(Heal*Mult*-1));
        else
            return((int)(Pain*Mult));
    }

}
