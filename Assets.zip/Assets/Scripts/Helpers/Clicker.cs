﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public class Clicker : MonoBehaviour
{
    public event Action LeftClick;
    public event Action RightClick;
    public event Action Hover;




    public GameObject selected = null;
    public GameObject hover = null;

    public int hovertime = 0;
    public int hovertimemax = 10;

    void Update () {
        
        Vector3 mousePos = Camera.main.ScreenToWorldPoint(Input.mousePosition);
        Vector2 mousePos2D = new Vector2(mousePos.x, mousePos.y);
            
        RaycastHit2D hit = Physics2D.Raycast(mousePos2D, Vector2.zero);
        
        if (hover != null)
            hover = null;

        if (hit.collider != null) { 
            hover = hit.collider.gameObject;
            Hover();

            if (Input.GetMouseButtonDown(0)) {
                if ((selected == null) && (hover.layer != 8)) { selected = hover;} else { selected = null;}

                if (LeftClick != null)
                    LeftClick();
            }
            //if (Input.GetMouseButtonUp(0)) {}

            if (Input.GetMouseButtonDown(1)) {
                if (selected == null) { selected = hover;} else { selected = null;}
                if (RightClick != null)
                    RightClick();
            }
            

        }
    }

}
