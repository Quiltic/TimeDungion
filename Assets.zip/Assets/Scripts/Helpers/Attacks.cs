﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Attacks : MonoBehaviour
{
   //public string aName;
   public GameObject createObject = null;

   public bool targetFirst = true; // hits the first thing in the row
   public bool targetRequreFront = true; // must be the first thing in the row
   public int targetForcedRange = 0; // is always X away
   public bool targetPickedRange = false; // pick where you want it to land
   
   public bool targetRow = false; // hits the entire row
   public bool targetCol = false; // hits the entire col

   //public int colSize = 1; // how many up/down this hits
   //public int rowSize = 1; // how many left/right this hits

   public char[] damage = {'p'}; // h,a,m are uneqe for now everything else is just dmg
   public int pearcing = 0; // how many it can perce though, damage is halfved for everything after the first
}
