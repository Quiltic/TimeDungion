﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Turns : MonoBehaviour
{
    public int currentTurn = 0;
    public GameObject current = null;
    CreatStats currentStats = null;


    // Start is called before the first frame update
    
    void ChangeTurn() {
        if (currentStats != null)
            current.GetComponent<BasicCreature>().TurnEnd();

        if (currentTurn >= gameObject.transform.childCount)
            currentTurn = 0;


        current = gameObject.transform.GetChild(currentTurn).gameObject;
        currentStats = current.GetComponent<CreatStats>();
        current.GetComponent<BasicCreature>().TurnStart();
        currentTurn++;
    }
    
    
    
    IEnumerator Start()
    {
        yield return new WaitForSeconds(0.3f);

        foreach (Transform child in transform)
        {
            child.SetSiblingIndex(child.GetComponent<CreatStats>().init);
        }
        //Debug.Log(transform.GetChild(0));
        ChangeTurn();
    }

    // Update is called once per frame
    void Update() {
        if (current != null) {
            if (currentStats.points <= 0 )
                ChangeTurn();
        }
        
    }

    
}
