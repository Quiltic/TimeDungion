﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Icon : MonoBehaviour
{
    public SpriteRenderer artwork;
    public Sprite currentSprite;

    void Awake() {
        artwork = gameObject.GetComponent<SpriteRenderer>();
        currentSprite = artwork.sprite;
    }

    public void SetArtworkSprite(Sprite art) {
        artwork.sprite = art;
        currentSprite = artwork.sprite;
    }

    public void ToggleVisable(bool state) {
        artwork.enabled = state;
    }
}