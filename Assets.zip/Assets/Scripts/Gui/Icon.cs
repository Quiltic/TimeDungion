﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Icon : MonoBehaviour
{
    public SpriteRenderer artwork;
    public Sprite currentSprite;

    void Awake() {
        artwork = gameObject.GetComponent<SpriteRenderer>();
        currentSprite = artwork.sprite;
    }

    public void SetArtworkSprite(Sprite art) {
        artwork.sprite = art;
        currentSprite = artwork.sprite;
    }

    public void ToggleVisable(bool state) {
        artwork.enabled = state;
    }

    public void ChangeColor(Color _color, float _oppacity = 1f) {
        artwork.color = _color - new Color (0, 0, 0, (1-_oppacity));
    }
}