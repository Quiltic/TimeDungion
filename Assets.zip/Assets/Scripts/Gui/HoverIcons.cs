﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HoverIcons : MonoBehaviour
{
    public GameObject iconTemplate;

    public Sprite[] hearts;
    public Sprite[] armors;
    public Sprite[] magicArmors;

    public Sprite strain;

    static int maxLength = 8;
    public Icon[] row = new Icon[maxLength];


    // Start is called before the first frame update
    void Awake()
    {

        for (var a = 0; a < maxLength; a++) {
            GameObject bab = Instantiate(iconTemplate, (gameObject.transform.position + new Vector3(a * 0.9F, 1f, -1)), Quaternion.identity);
            bab.transform.parent = gameObject.transform;
            row[a] = bab.GetComponent<Icon>();
            row[a].ToggleVisable(false);
            row[a].SetArtworkSprite(hearts[0]);
        }
    }


    public void Resize(float scaleDown) {
        scaleDown = 1f / scaleDown;
        foreach (Icon tip in row) {
            tip.transform.localScale = new Vector3(scaleDown,scaleDown,scaleDown);
        }
    }


    public void Clear() {
        foreach (Icon tip in row) {
            tip.ToggleVisable(false);
            tip.artwork.color = new Color(1f,1f,1f,1f);
        }
    }


    public void Shove(int amountToShow) {
        int index = 0;
        amountToShow--;
        foreach (Icon tip in row) {
            tip.transform.position = (gameObject.transform.position + new Vector3( ((index * 0.9F) - (amountToShow * 0.9F)/2), 1.5f, -1));
            index++;
        }
    }



    public void ShowHP(int hp, int maxHP, int armor, int magicArmor) {
        Clear();
        Shove(maxHP + armor + magicArmor);
        int index = 0;
        foreach (Icon tip in row) {

            tip.ToggleVisable(true);

            if (hp > index) {
                tip.SetArtworkSprite(hearts[0]);

            } else if (maxHP > index) {
                tip.SetArtworkSprite(hearts[1]);

            } else if (armor > (index - maxHP)) {
                tip.SetArtworkSprite(armors[0]);

            } else if (magicArmor > (index - maxHP - armor)) {
                tip.SetArtworkSprite(magicArmors[0]);
            
            } else {
                tip.ToggleVisable(false);
            }

            index++;
        }
    }


    public void ShowPoints(int maxPoints, int points) {
        Clear();
        Shove(maxPoints);
        int index = 0;
        foreach (Icon tip in row) {

            tip.ToggleVisable(true);

            if (points > index) {
                tip.SetArtworkSprite(strain);

            } else if (maxPoints > index) {
                tip.SetArtworkSprite(strain);
                tip.artwork.color = new Color(0.5f,0.5f,0.5f,1f);
            
            } else {
                tip.ToggleVisable(false);
            }

            index++;
        }
    }


    public void ShowHurt(Attacks thing, int magicArmor, int armor) {
        Clear();
        
        int index = 0;
        //foreach (AttackData thing in damage) {
        if (thing != null) {
            //thing.ShowIndicator(true);
            foreach (char tip in thing.damage) {
                row[index].ToggleVisable(true);

                if (tip == '\0')
                    continue;
                else if ((tip == 'h') && (magicArmor <= 0) && (armor <= 0)) { // hp
                    row[index].SetArtworkSprite(hearts[1]);

                } else if (tip == 'm') { // magic
                    if (magicArmor > 0) {
                        row[index].SetArtworkSprite(magicArmors[1]);
                        magicArmor--;
                    }

                } else if (tip == 'a') { // armor
                    if (armor > 0) {
                        row[index].SetArtworkSprite(armors[1]);
                        armor--;
                    }

                } else {  // general
                    if (magicArmor > 0) {
                        row[index].SetArtworkSprite(magicArmors[1]);
                        magicArmor--;
                    } else if (armor > 0) {
                        row[index].SetArtworkSprite(armors[1]);
                        armor--;
                    } else {
                        row[index].SetArtworkSprite(hearts[1]);
                    }
                }

            index++;
            }
        }
        //}

        Shove(index);
    }
}