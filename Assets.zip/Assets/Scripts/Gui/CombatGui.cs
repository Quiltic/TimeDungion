﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class CombatGui : MonoBehaviour
{

    private Clicker main;

    public GameObject creature;
    Player target;


    public GameObject iconTemplate;

    public Sprite heart;
    public Sprite heartBroken;
    public Sprite armor;
    public Sprite magicArmor;

    public Sprite strain;

    public static int maxHpLength = 8;
    public Icon[] hpRow = new Icon[maxHpLength];

    public static int maxPointsLength = 8;
    public Icon[] pointsRow = new Icon[maxPointsLength];


    //public TMP_Text targetName;
    

    void UpdateHealth() {
        int index = 0;
        foreach (Icon tip in hpRow) {

            tip.ToggleVisable(true);

            if (target.hp > index) {
                tip.SetArtworkSprite(heart);

            } else if (target.maxHP > index) {
                tip.SetArtworkSprite(heartBroken);

            } else if (target.armor > (index - target.maxHP)) {
                tip.SetArtworkSprite(armor);

            } else if (target.magicArmor > (index - target.maxHP - target.armor)) {
                tip.SetArtworkSprite(magicArmor);
            
            } else {
                tip.ToggleVisable(false);
            }

            index++;
        }
    }


    void UpdatePoints() {
        int index = 0;
        foreach (Icon tip in pointsRow) {

            tip.ToggleVisable(true);

            if (target.points > index) {
                tip.SetArtworkSprite(strain);

            } else if (target.maxPoints > index) {
                tip.artwork.color = new Color(0.5f,0.5f,0.5f,1f);
            
            } else {
                tip.ToggleVisable(false);
            }

            index++;
        }
    }


    // Start is called before the first frame update
    void Start()
    {
        main = GameObject.Find("Main Camera").GetComponent<Clicker>();

        main.LeftClick += NewTarget;

        for (var a = 0; a < maxHpLength; a++) {
            GameObject bab = Instantiate(iconTemplate, (gameObject.transform.position + new Vector3(a * 0.9F, -0.55f, 0)), Quaternion.identity);
            bab.transform.parent = gameObject.transform;
            hpRow[a] = bab.GetComponent<Icon>();
            hpRow[a].ToggleVisable(false);
            hpRow[a].SetArtworkSprite(heart);
        }

        /*
        for (var a = 0; a < maxPointsLength; a++) {
            GameObject bab = Instantiate(iconTemplate, (gameObject.transform.position + new Vector3(a * 0.9F, -1.5f, 0)), Quaternion.identity);
            bab.transform.parent = gameObject.transform;
            pointsRow[a] = bab.GetComponent<Icon>();
            pointsRow[a].ToggleVisable(false);
            pointsRow[a].SetArtworkSprite(strain);
        }
        */
        
        

        //Vector3 cameraPosition = Camera.main.ScreenToWorldPoint(new Vector3(0, Screen.height, 5));
        //gameObject.transform.Translate(cameraPosition);

        //gameObject.transform.Rotate(30, -45, 0); // rotating it before hand does weard things. Idk why though

        //transform.localPosition += new Vector3(Heart.bounds.size.x/2 + 0.2f, -(Heart.bounds.size.y/2),0);

        if (creature) {
            //targetName.text = creature.name;
            target = creature.GetComponent<Player>();
            target.HpChange += UpdateHealth;
            //target.PointsChange += UpdatePoints;
            UpdateHealth();
            //UpdatePoints();
        }
    }


    void NewTarget() {
        
        // this is where the getting a new creature code should go

        //

        if (main.selected) {
            if (main.selected.tag == "Player") {
                creature = main.selected;
                //targetName.text = creature.name;
                target = creature.GetComponent<Player>();
                target.HpChange += UpdateHealth;
                //target.PointsChange += UpdatePoints;
                UpdateHealth();
                //UpdatePoints();
            }
        }

    }


    // Update is called once per frame
    //void Update(){}


}
