﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class CreatStats : MonoBehaviour
{

    public int totalHP = 1;
    public int hp = 0;
    public int maxHP = 0;
    public int armor = 1;
    public int magicArmor = 0;

    public int maxPoints = 0;
    public int points = 0;
    public int pointsRegen = 0;
    //*/
    public int locX = 0;
    public int locY = 0;
    public int speed = 2;
    public int init = 0;

    public int TakeDamage(char[] damage) {
        //Debug.Log(damage);
        // order of damage magic, armor, hp
        foreach (char tip in damage) {
            if ((tip == 'h') && (magicArmor <= 0) && (armor <= 0)) { // hp
                hp--;

            } else if (tip == 'm') { // magic
                if (magicArmor > 0) {
                    magicArmor--;
                }

            } else if (tip == 'a') { // armor
                if (armor > 0) {
                    armor--;
                }

            } else {  // general
                if (magicArmor > 0) {
                    magicArmor--;
                } else if (armor > 0) {
                    armor--;
                } else {
                    hp--;
                }
            }
        }
        
        totalHP = hp + armor + magicArmor;

        return(totalHP);
    }


}
