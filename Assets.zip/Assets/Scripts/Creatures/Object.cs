﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
//using Stats;

public class Object : MonoBehaviour
{
    protected Clicker main;

    public event Action HpChange;
    public event Action PointsChange;
    public event Action Died;
    

    public Floor homeGrid;

    //public CreatureStats stats = new CreatureStats(); // doesent show in inspector means many much problems


    ///*
    public int totalHP = 1;
    public int hp = 0;
    public int maxHP = 0;
    public int armor = 1;
    public int magicArmor = 0;

    public int maxPoints = 0;
    public int points = 0;
    public int pointsRegen = 0;
    //*/


    public int[] loc = {0,0};
    


    public float size = 1.7f;
    protected Vector3 scaleChange;
    public bool fliped = false;

    protected bool hover = false;
    protected bool click = false;

    protected HoverIcons showStats;
    

    
    
    void Start()
    {
        main = GameObject.Find("Main Camera").GetComponent<Clicker>();
        main.LeftClick += Clicked;
        main.RightClick += Approve;

        homeGrid.SetOcc(loc[0],loc[1], gameObject);
        gameObject.transform.position = homeGrid.selfGrid[loc[0],loc[1]].GetPos() + new Vector3(0,0.65f,-1);
        scaleChange = new Vector3(-0.015f, -0.015f, -0.015f); // for enlargeing/shrinking

        showStats = gameObject.GetComponent<HoverIcons>();
        main.Hover += OnHover;
        showStats.Resize(size);

    }


    public void TakeDamage(char[] damage) {
        //Debug.Log(damage);
        // order of damage magic, armor, hp
        foreach (char tip in damage) {
            if ((tip == 'h') && (magicArmor <= 0) && (armor <= 0)) { // hp
                hp--;

            } else if (tip == 'm') { // magic
                if (magicArmor > 0) {
                    magicArmor--;
                }

            } else if (tip == 'a') { // armor
                if (armor > 0) {
                    armor--;
                }

            } else {  // general
                if (magicArmor > 0) {
                    magicArmor--;
                } else if (armor > 0) {
                    armor--;
                } else {
                    hp--;
                }
            }
        }
        
        totalHP = hp + armor + magicArmor;

        if (totalHP <= 0) {
            
            if (Died != null)
                Died();


            homeGrid.selfGrid[loc[0],loc[1]].Occupied = null;
            main.LeftClick -= Clicked;
            main.RightClick -= Approve;
            main.Hover -= OnHover;
            Destroy(gameObject);
        }

        if (HpChange != null)
            HpChange();
    } 



    protected void Clicked(){
        if (main.selected) {
            if (main.selected.name == gameObject.name){
                click = true;
            
            } else {
                click = false;
            }

        } else {
            click = false;
        }

    }


    protected void OnHover() {
        if (click) {
            //showStats.Resize(size);
            showStats.ShowPoints(maxPoints, points);

        } else if (main.hover == gameObject) {
            //showStats.Resize(size);
            showStats.ShowHP(hp, maxHP, armor, magicArmor);

        } else {

            showStats.Clear();

        }

    }

    void Approve(){
        //dummy function does nothing.
        click = false;
    }


    void Update() {
        if (click) {
            gameObject.transform.localScale += scaleChange;
            if (gameObject.transform.localScale.y < (size-0.25f) || gameObject.transform.localScale.y > (size+0.25f))
                scaleChange = -scaleChange;
        } else {
            if (gameObject.transform.localScale.z != size) {
                if (fliped) {gameObject.transform.localScale = new Vector3(-size,size,size);} else {gameObject.transform.localScale = new Vector3(size,size,size);}
            }
        }
    }

    
}
