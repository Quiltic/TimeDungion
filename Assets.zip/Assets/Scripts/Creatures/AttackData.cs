﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AttackData : MonoBehaviour
{

    public Attacks active; // this is to be the damage taken from the attack

    public Attacks[] Abilitys = new Attacks[2]; 
    public Icon pointer; // gives a red box saying that it is attacking x
    public int abilitySelected = 0;



    public void SwapActive(int selected) {
        abilitySelected = selected;
        active = Abilitys[abilitySelected]; // Should be a pointer but dont want to tempt fate
    }


    public void ShowIndicator(bool show) {
        pointer.ToggleVisable(show);
    }

    private void Awake() {
        pointer.ToggleVisable(false);
        SwapActive(0);
    }



}
