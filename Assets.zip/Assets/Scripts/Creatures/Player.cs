﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using System.Linq;


public class Player : Object
{


    /*
    Fighter hits front row for 2 : block
    Archer  hits 2 tiles away row for 1 : trap on other side
    Wisard  hits row for 2 on first 1 on second : wall on other side

    */


    
    public Floor awayGrid;

    
	//public float movespeed = 10; // this is for movement visuals
    public int speed = 2;


    public Attacks[] Abilitys = new Attacks[2];
    public GameObject pointer;
    public int abilitySelected = 0;

    public GameObject[] targets = new GameObject[3];

    void Start()
    {
        main = GameObject.Find("Main Camera").GetComponent<Clicker>();
        //leftGrid = GameObject.Find("LeftSide").GetComponent<Floor>();
        //rightGrid = GameObject.Find("RightSide").GetComponent<Floor>();

        main.LeftClick += Clicked;
        main.RightClick += Approve;

        homeGrid.SetOcc(loc[0],loc[1], gameObject);

        scaleChange = new Vector3(-0.05f, -0.05f, -0.05f); // for enlargeing/shrinking

        showStats = gameObject.GetComponent<HoverIcons>();
        main.Hover += OnHover;
        showStats.Resize(size);
    }

    


    void Update() {


        // to know if you have been clicked I got a weard grow code. extreamly helpfull
        if (click) {

            if (main.hover) {

                if (main.hover.transform.position.x < 2) { // home


                    if (main.hover.layer == 8) {
                        Cell temp = main.hover.GetComponent<Cell>();

                        if (main.hover.transform.parent.name == homeGrid.selfName) { // Home
                            
                            if ((Math.Abs(loc[0] - temp.x) <= speed) && (Math.Abs(loc[1] - temp.y) <= speed))
                                pointer.GetComponent<Icon>().artwork.color = new Color(0f,0f,1f,0.3f);
                            else {
                                pointer.GetComponent<Icon>().artwork.color = new Color(1f,0f,0f,0.3f);
                            }
                        
                            pointer.transform.position = main.hover.transform.position + new Vector3(0,0,-2);
                        }
                    }


                } else { // away
                    Fight();
                }


            } else { if (pointer.transform.position.z != -15) pointer.transform.position = new Vector3(0,0,-15); }


            gameObject.transform.localScale += scaleChange;
            if (gameObject.transform.localScale.y < (size-0.5f) || gameObject.transform.localScale.y > (size+0.5f))
                scaleChange = -scaleChange;
        } else {

            if (gameObject.transform.localScale.z != size) {
                if (fliped) {gameObject.transform.localScale = new Vector3(-size,size,size);} else {gameObject.transform.localScale = new Vector3(size,size,size);}
                pointer.transform.position = new Vector3(0,0,-15);
            }

        }

    }



    void Move() {
        if (click) {
            if (main.hover.layer == 8) {
                Cell temp = main.hover.GetComponent<Cell>();

                if ((temp.Occupied == null) && (main.hover.transform.parent.name == homeGrid.selfName) && ((Math.Abs(loc[0] - temp.x) <= speed) && (Math.Abs(loc[1] - temp.y) <= speed))) {

                    gameObject.transform.position = main.hover.transform.position + new Vector3(0,1,-1); // move
                    homeGrid.SetOcc(loc[0],loc[1], null);
                    
                    //leftGrid.selfGrid[loc[0],loc[1]].Occupied = null; // set current cell to be empty

                    temp.Occupied = gameObject; // set moved to cell to be full
                    loc[0] = temp.x; // new loc
                    loc[1] = temp.y;

                }
            }
            
            click = false;
            pointer.transform.position = new Vector3(0,0,-15);
        }
    }


    


    void Approve() {
        if (main.hover){
            if (main.hover.transform.position.x < 2) // move
                Move();


            else { //attack
                Fight();
                int pearsed = 0;
                foreach (GameObject thing in targets) {
                    if (thing) {
                        try {
                            if (pearsed > 0)
                                thing.GetComponent<Player>().TakeDamage(Abilitys[abilitySelected].damage.Take((int)Math.Ceiling(Abilitys[abilitySelected].damage.Length/2f)).ToArray());
                            else {
                                thing.GetComponent<Player>().TakeDamage(Abilitys[abilitySelected].damage);
                            }


                        } catch {

                            if (pearsed > 0)
                                thing.GetComponent<Object>().TakeDamage(Abilitys[abilitySelected].damage.Take((int)Math.Ceiling(Abilitys[abilitySelected].damage.Length/2f)).ToArray());
                            else {
                                thing.GetComponent<Object>().TakeDamage(Abilitys[abilitySelected].damage);
                            }
                            

                        } finally {
                            pearsed++;
                        }
                    }
                }
                targets = new GameObject[3];
                click = false;
            }
            

        }
    }


    void Fight() {

        targets = new GameObject[3];
        int pearsed = 0;
        bool working = true;


        if (Abilitys[abilitySelected].targetRequreFront) {
            for( int a = 0; a < awayGrid.scale; a++ ) {
                
                pointer.transform.position = homeGrid.selfGrid[a,loc[1]].GetPos() + new Vector3(0,0,-2);
                if (homeGrid.selfGrid[a,loc[1]].Occupied == gameObject)
                    break;
                
                if (homeGrid.selfGrid[a,loc[1]].Occupied != null) {
                    targets[pearsed] = homeGrid.selfGrid[a,loc[1]].Occupied;
                    pearsed++;
                    
                    pointer.GetComponent<Icon>().artwork.color = new Color(1f,0f,0f,0.3f);

                    if (pearsed > Abilitys[abilitySelected].pearcing) {
                        working = false;
                        break;
                    }
                }     
            }
        }


        if (working) {
            if (Abilitys[abilitySelected].targetFirst) {
                for( int a = 0; a < awayGrid.scale; a++ ) {

                    pointer.transform.position = awayGrid.selfGrid[a,loc[1]].GetPos() + new Vector3(0,0,-2);
                    if (awayGrid.selfGrid[a,loc[1]].Occupied != null) {
                        targets[pearsed] = awayGrid.selfGrid[a,loc[1]].Occupied;
                        pearsed++;
                        
                        if (pearsed > Abilitys[abilitySelected].pearcing)
                            break;
                    }
                }

            } else if (Abilitys[abilitySelected].targetForcedRange != 0) {
                int a = Math.Abs(Abilitys[abilitySelected].targetForcedRange-loc[0]-1);

                pointer.transform.position = awayGrid.selfGrid[a,loc[1]].GetPos() + new Vector3(0,0,-2);
                
                if (awayGrid.selfGrid[a,loc[1]].Occupied != null) {
                        targets[pearsed] = awayGrid.selfGrid[a,loc[1]].Occupied;
                        pearsed++;
                }

                // This is where pearcing stuff would go

            }

            pointer.GetComponent<Icon>().artwork.color = new Color(0f,1f,0f,0.3f);

        }
    }
}






