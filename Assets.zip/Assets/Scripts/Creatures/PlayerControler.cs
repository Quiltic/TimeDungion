﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public class PlayerControler : MonoBehaviour
{

    //BasicCreature home;
    public Floor awayGrid;
    public GameObject pointer;
    Icon pointerIcon;
    
    
    AttackData abilitys;


    private void Awake() {
        pointerIcon = pointer.GetComponent<Icon>();
        abilitys = gameObject.GetComponent<AttackData>();
    }



    public void ChangeAbility() {
        if (Input.GetButtonDown("Selector1"))
            abilitys.SwapActive(0);
        if (Input.GetButtonDown("Selector2"))
            abilitys.SwapActive(1);
    }


    public void ShowMovement(GameObject hover, CreatStats stats) {
        if (hover.layer == 8) {
            Cell temp = hover.GetComponent<Cell>();
            //if (hover.transform.parent.name == homeGrid.selfName) { // Home
            
            if ((Math.Abs(stats.locX - temp.x) <= stats.speed) && (Math.Abs(stats.locY - temp.y) <= stats.speed))
                pointerIcon.ChangeColor(Color.blue, 0.3f); //.artwork.color = new Color(0f,0f,1f,0.3f);
            else {
                pointerIcon.ChangeColor(Color.red, 0.3f); //.artwork.color = new Color(1f,0f,0f,0.3f);
            }
        
            pointer.transform.position = hover.transform.position + new Vector3(0,0,-2);
        
        } else {
            RemovePointer();
        }
    }

    public void RemovePointer() {
        pointer.transform.position = new Vector3(0,0,-20);
    }




    // I DONT KNOW WHAT THIS IS!
    public void ShowHit(GameObject hover, CreatStats stats) {
        if (hover.layer == 8) {
            Cell temp = hover.GetComponent<Cell>();
            //if (hover.transform.parent.name == homeGrid.selfName) { // Home
            
            if ((Math.Abs(stats.locX - temp.x) <= stats.speed) && (Math.Abs(stats.locY - temp.y) <= stats.speed))
                pointerIcon.ChangeColor(Color.blue, 0.3f); //.artwork.color = new Color(0f,0f,1f,0.3f);
            else {
                pointerIcon.ChangeColor(Color.red, 0.3f); //.artwork.color = new Color(1f,0f,0f,0.3f);
            }
        
            pointer.transform.position = hover.transform.position + new Vector3(0,0,-2);
        
        } else {
            RemovePointer();
        }
    }



    public void Fight(CreatStats stats, Floor homeGrid) {
        bool isFront = false;
        if (abilitys.active.targetRequreFront) { isFront = RequreFront(homeGrid, stats);}

        if (isFront)
            if (abilitys.active.targetFirst) { TargetFirst(stats);}
    }



    bool RequreFront(Floor homeGrid, CreatStats stats) {
        GameObject freind = null;

        for( int a = 0; a < homeGrid.scale; a++ ) {
            freind = homeGrid.selfGrid[a,stats.locY].Occupied;
            
            if (freind == gameObject)
                break;
            
            if (freind != null) {
                
                freind.GetComponent<BasicCreature>().TargetedBy(abilitys.active);
                
                pointer.GetComponent<Icon>().artwork.color = new Color(1f,0f,0f,0.3f);
                pointer.transform.position = homeGrid.selfGrid[a,stats.locY].GetPos() + new Vector3(0,0,-2);

                //if (pearsed > abilitys.active.pearcing) {
                return(false);
                //}
            }     
        }
        return(true);
    }


    GameObject[] TargetFirst(CreatStats stats) {
        int pearsed = 0;
        GameObject foe = null;
        GameObject[] targets = new GameObject[3];

        for( int a = 0; a < awayGrid.scale; a++ ) {

            foe = awayGrid.selfGrid[a,stats.locY].Occupied;

            pointer.transform.position = awayGrid.selfGrid[a,stats.locY].GetPos() + new Vector3(0,0,-2);

            if (foe != null) {
                targets[pearsed] = awayGrid.selfGrid[a,stats.locY].Occupied;
                pearsed++;

                foe.GetComponent<BasicCreature>().TargetedBy(abilitys.active); // doesent show less damage from pearsed

                
                if (pearsed > abilitys.active.pearcing)
                    break;
            }
        }
        return(targets);
    }



    /*
    public void Fight(AttackData abilitys, CreatStats stats) {

        int pearsed = 0;
        bool working = true;


        if (abilitys.active.targetRequreFront) {
            for( int a = 0; a < awayGrid.scale; a++ ) {
                
                pointer.transform.position = homeGrid.selfGrid[a,stats.locY].GetPos() + new Vector3(0,0,-2);
                if (homeGrid.selfGrid[a,stats.locY].Occupied == gameObject)
                    break;
                
                if (homeGrid.selfGrid[a,stats.locY].Occupied != null) {
                    targets[pearsed] = homeGrid.selfGrid[a,stats.locY].Occupied;
                    pearsed++;
                    
                    pointer.GetComponent<Icon>().artwork.color = new Color(1f,0f,0f,0.3f);

                    if (pearsed > abilitys.active.pearcing) {
                        working = false;
                        break;
                    }
                }     
            }
        }


        if (working) {
            if (abilitys.active.targetFirst) {
                for( int a = 0; a < awayGrid.scale; a++ ) {

                    pointer.transform.position = awayGrid.selfGrid[a,stats.locY].GetPos() + new Vector3(0,0,-2);
                    if (awayGrid.selfGrid[a,stats.locY].Occupied != null) {
                        targets[pearsed] = awayGrid.selfGrid[a,stats.locY].Occupied;
                        pearsed++;
                        
                        if (pearsed > abilitys.active.pearcing)
                            break;
                    }
                }

            } else if (abilitys.active.targetForcedRange != 0) {
                int a = Math.Abs(abilitys.active.targetForcedRange-loc[0]-1);

                pointer.transform.position = awayGrid.selfGrid[a,stats.locY].GetPos() + new Vector3(0,0,-2);
                
                if (awayGrid.selfGrid[a,stats.locY].Occupied != null) {
                        targets[pearsed] = awayGrid.selfGrid[a,stats.locY].Occupied;
                        pearsed++;
                }

                // This is where pearcing stuff would go

            }

            pointer.GetComponent<Icon>().artwork.color = new Color(0f,1f,0f,0.3f);

        }
    }
}
*/





}
