﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;



public class BasicCreature : MonoBehaviour
{

    public event Action HpChange;
    public event Action PointsChange;
    public event Action Died;




    protected Clicker main;
    public bool hover = false;
    public bool click = false;

    protected CreatStats stats;
    public Floor homeGrid;


    //public int currentTargetSpot = 0;
    //public AttackData[] targeted = new AttackData[8];// {null,null,null,null,null,null,null}; // otherside(3), trap(1), freind(2), world(1) :: Not all will be used and at best 3 will go off

    protected HoverIcons showStats;
    public float size = 1.7f;
    protected Vector3 scaleChange;
    public bool fliped = false;


    protected PlayerControler playerControler = null;






    protected void Clicked(){
        click = false;
        if (main.selected) {
            if (main.selected.name == gameObject.name)
                click = true;
        }
    }


    void Approve(){
        //dummy function does nothing. used for overides on child scripts
        
        if (click) {
            if (playerControler != null) {

                if (main.hover) {

                    if (main.hover.transform.position.x < 2) { // move
                        if ((stats.points > 0) && (main.hover.layer == 8)) {
                            var cell = main.hover.GetComponent<Cell>();
                            if (Move(cell.x,cell.y))
                                ReducePoints(1);
                        }
                    
                    } else { // attack

                    }
                
                }
            }


        }

        
        click = false;
    }


    protected void OnHover() {
        /*
        // remove the glow of being attacked
        foreach (AttackData thing in targeted) {
            if (thing != null) {
                thing.ShowIndicator(false);
            }
        }
        */




        if (click) {
            //showStats.ShowPoints(stats.maxPoints, stats.points);

        } else if (main.hover == gameObject) {
            //if (targeted[0] != null)
            //    showStats.ShowHurt(targeted, stats.magicArmor, stats.armor);
            //else {
                showStats.ShowHP(stats.hp, stats.maxHP, stats.armor, stats.magicArmor);
            //}

        } else {
            showStats.Clear();

        }
    }








    public void TargetedBy(Attacks attacker) {
        // doesent show less damage from pearsed

        showStats.ShowHurt(attacker, stats.magicArmor, stats.armor);
        // this is here so that I can add other events to this later on
        //targeted[currentTargetSpot] = attacker;
        //currentTargetSpot++;
    }


    public void Wobble() {
        if (click) {
            gameObject.transform.localScale += scaleChange;
            if (gameObject.transform.localScale.y < (size-(0.0472f * size + 0.17f)) || gameObject.transform.localScale.y > (size+(0.0472f * size + 0.17f)))
                scaleChange = -scaleChange;
        } else {
            if (gameObject.transform.localScale.z != size) {
                if (fliped) {gameObject.transform.localScale = new Vector3(-size,size,size);} else {gameObject.transform.localScale = new Vector3(size,size,size);}
            }
        }
    }


    public void ChangeScale(Vector3 scale) {
        scaleChange = scale;
    }


    public void TurnStart() {
        // order this goes in
        // points regen
        // if statussed : status stuff 
        // if AI : move

        // points regen
        Debug.Log(stats);
        ReducePoints(-stats.pointsRegen);
        click = true;


        // statuses
        


        // AI Move

    }


    public void TurnEnd() {
        click = false;
    }


    protected void RoundStart() {
        // order this goes in
        // if targeted : damage
        // points regen
        // if statussed : status stuff 
        // if AI : move
        

        // damage
        //int index = 0;
        //foreach (AttackData hit in targeted) {
        //    hit.ShowIndicator(false);

        //    IsDead(stats.TakeDamage(hit.active.damage));
            //targeted[index] = null; // I dont know how to change them all to null afterwords
            //index++;
        //}

        //targeted = new AttackData[8];// {null,null,null,null,null,null,null};
        //currentTargetSpot = 0;


        // points regen
        ReducePoints(-stats.pointsRegen);


        // statuses
        


        // AI Move

    }


    protected void IsDead(int totalHP) {
        if (totalHP <= 0) {
            if (Died != null)
                Died();


            homeGrid.selfGrid[stats.locX,stats.locY].Occupied = null;
            main.LeftClick -= Clicked;
            main.RightClick -= Approve;
            main.Hover -= OnHover;
            Destroy(gameObject);
        
        } else {
            if (HpChange != null)
                HpChange();
        }
    }


    public bool Move(int x, int y) {
        Cell temp = homeGrid.selfGrid[x,y];
        // Check to see if it can achualy move
        if ((temp.Occupied == null) && ((Math.Abs(stats.locX - temp.x) <= stats.speed) && (Math.Abs(stats.locY - temp.y) <= stats.speed))) {
            gameObject.transform.position = temp.GetPos() + new Vector3(0,0.64f,-1);//main.hover.transform.position + new Vector3(0,1,-1); // move
            
            if (gameObject.tag != "Object")
                gameObject.transform.position += new Vector3(0,0.36f,0); // temp


            homeGrid.SetOcc(stats.locX,stats.locY, null);
            temp.Occupied = gameObject; // set moved to cell to be full

            stats.locX = temp.x; // new loc
            stats.locY = temp.y;
            
            
            return(true);
        }
        return(false);
    }


    public void ReducePoints(int amount) {
        if (PointsChange != null)
            PointsChange();
        stats.points -= amount;
        if (stats.points > stats.maxPoints) // negitive numbers are regaining
            stats.points = stats.maxPoints;
    }










     protected void Start() 
    {
        main = GameObject.Find("Main Camera").GetComponent<Clicker>();
        main.LeftClick += Clicked;
        main.RightClick += Approve;

        stats = gameObject.GetComponent<CreatStats>();

        //homeGrid.SetOcc(stats.locX,stats.locY, gameObject);
        //gameObject.transform.position = homeGrid.selfGrid[stats.locX,stats.locY].GetPos() + new Vector3(0,0.65f,-1);
        Move(stats.locX,stats.locY);


        showStats = gameObject.GetComponent<HoverIcons>();
        main.Hover += OnHover;
        showStats.Resize(size);

        main.NewRound += RoundStart;

        scaleChange = new Vector3(-(0.007f*size+0.003f), -(0.007f*size+0.003f), -(0.007f*size+0.003f));
        Wobble();


        try {
            playerControler = gameObject.GetComponent<PlayerControler>();
        } catch {
            playerControler = null;
        }

    }





    private void Update() {
        Wobble();

        if (click) {
            showStats.ShowPoints(stats.maxPoints, stats.points);
            if (playerControler != null) {

                if (main.hover) {

                    if (main.hover.transform.position.x < 2) { // move
                        playerControler.ShowMovement(main.hover,stats);
                    
                    } else { // attack
                        playerControler.ChangeAbility();
                        playerControler.Fight(stats, homeGrid);
                    }
                
                } else {
                    playerControler.RemovePointer();
                }
            }
        }
    }



}
