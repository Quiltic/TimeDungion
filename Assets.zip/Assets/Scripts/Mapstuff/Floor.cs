﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public class Floor : MonoBehaviour
{

    //https://stackoverflow.com/questions/19002044/need-to-convert-comma-separated-data-from-a-file-into-a-list-of-object

    public int scale = 2;
    public bool mirror = false;

    int sizex;
    int sizey;
    public float enlarge;

    public GameObject prefab;
    public Cell[,] selfGrid;
    //public int[] array = new int[4];

    public string selfName;



    void Awake() {

        selfName = gameObject.name;

        sizex = scale;
        sizey = 2*scale-1;
        selfGrid = new Cell[sizex,sizey];

        enlarge = -0.3f*scale + 2f;

        for (int x = 0; x < sizex; x++) {
            for (int y = 0; y < sizey; y++) {
                GameObject bab = Instantiate(prefab, (gameObject.transform.position + new Vector3(x, (-y*0.7f)+1, -y)), Quaternion.identity);
                bab.transform.parent = gameObject.transform;
                //bab.transform.localScale += new Vector3(-0.4f,-0.4f,-0.4f);
                //bab.GetComponent<Cell>().giveXY(x,y);
                selfGrid[x,y] = bab.GetComponent<Cell>();
                selfGrid[x,y].giveXY(x,y);
                
            }    
        }
        
        gameObject.transform.localScale += new Vector3(enlarge,enlarge,enlarge);

        if (mirror)
            gameObject.transform.localScale = new Vector3(-gameObject.transform.localScale.x,gameObject.transform.localScale.y,gameObject.transform.localScale.z);
    }


    public void SetOcc(int _x, int _y, GameObject _thing) {
        selfGrid[_x,_y].Occupied = _thing;
    }
    // Update is called once per frame
    //void Update(){}
    
    
    
}
