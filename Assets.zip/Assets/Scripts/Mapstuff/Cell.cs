﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Cell : MonoBehaviour
{

    public int x;
    public int y;

    public GameObject Occupied = null;

    Icon self;

    void Awake() {
        self = gameObject.GetComponent<Icon>();
    }

    public Vector3 GetPos() {
        return(gameObject.transform.position);
    }

    public void giveXY(int _x, int _y) {
        x = _x;
        y = _y;
    }


    // Update is called once per frame
    //void Update() {}
}
