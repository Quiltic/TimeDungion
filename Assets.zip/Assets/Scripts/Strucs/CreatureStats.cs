﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Stats {
    public class CreatureStats
    {
        public int totalHP;
        public int hp;
        public int maxHP;
        public int armor;
        public int magicArmor;

        public int maxPoints;
        public int points;
        public int pointsRegen;

        public CreatureStats() {
            totalHP = 1;
            hp = 0;
            maxHP = 0;
            armor = 1;
            magicArmor = 0;

            maxPoints = 0;
            points = 0;
            pointsRegen = 0;
        }
    }

    

}
